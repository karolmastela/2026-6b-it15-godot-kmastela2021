# Assets

| Asset | Quelle | Lizenz |
|---|---|---|
| Alle Grafiken im Prototyp | Platzhalter aus Godot-Formen (ColorRect, Polygon2D), selbst erstellt | eigenes Werk |
| Schrift | Godot-Standardschrift | Open Font License |
| Sounds / Musik | noch keine (kommt in Aufgabe 15.15) | – |

Echte Grafiken (z. B. Kenney „Pixel Platformer“, CC0) folgen in Aufgabe 15.16.

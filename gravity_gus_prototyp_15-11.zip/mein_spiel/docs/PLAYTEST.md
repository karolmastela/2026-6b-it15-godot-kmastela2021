# Playtest-Notizen – Prototyp (Aufgabe 15.11)

> Spiele den Prototyp mindestens 10 Minuten (am besten auch mit jemand anderem) und trage dann **deine eigenen** Beobachtungen ein.

**Datum:** [ausfüllen]  
**Getestet von:** [Name(n)]  
**Spielzeit:** [z. B. 12 Minuten]

## Das macht Spaß (3 Dinge)

1. [ausfüllen]
2. [ausfüllen]
3. [ausfüllen]

## Das nervt (3 Dinge)

1. [ausfüllen]
2. [ausfüllen]
3. [ausfüllen]

## Verbesserungen, die ich umgesetzt habe (mindestens 2)

| Problem | Änderung (was genau?) | Ergebnis |
|---|---|---|
| [ausfüllen] | [ausfüllen] | [ausfüllen] |
| [ausfüllen] | [ausfüllen] | [ausfüllen] |

## Tipp: Diese Werte kannst du im Inspector einstellen (Tuning)

- **Player** (`player.tscn`, Knoten *Player*): `speed`, `jump_impulse`, `gravity`, `coyote_time`, `jump_buffer_time`, `stomp_bounce`, `flip_cooldown`, `invulnerable_time`
- **Walker** (`walker.tscn`): `speed`, `points`
- **Flyer** (`flyer.tscn`): `speed`, `patrol_range`, `wave_amplitude`, `wave_frequency`
- **Level** (`main.tscn`): Position/Größe der Plattformen, Stacheln, Gegner und Münzen direkt im Editor verschieben

Schreibe hier nur Änderungen auf, die du wirklich gemacht und ausprobiert hast.

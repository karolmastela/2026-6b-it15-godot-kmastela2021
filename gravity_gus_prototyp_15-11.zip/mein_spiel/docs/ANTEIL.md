# Anteil (Gruppenarbeit) – Aufgabe 15.11

Jede Person gibt nur ihren eigenen Anteil ab. Trage hier ein, wer was gemacht hat (Dateien und Commits unter dem eigenen GitHub-Namen).

| Person | Dateien / Bereich | Commits (Links) |
|---|---|---|
| [Mohammed] | [z. B. scripts/game_state.gd, scenes/hud.tscn, scripts/hud.gd, project.godot (Input Map, Autoload)] | [Link] |
| Karol Mastela | [z. B. scenes/player.tscn, scripts/player.gd, Level in scenes/main.tscn, Gegner] | [Link] |

extends Area2D
## Checkpoint: nach einem Leben-Verlust startet der Spieler hier wieder.

@onready var flag: ColorRect = $Flag

var _active: bool = false


func _ready() -> void:
	body_entered.connect(_on_body_entered)


func _on_body_entered(body: Node2D) -> void:
	if _active or not body.is_in_group("player"):
		return
	_active = true
	body.set_checkpoint(global_position + Vector2(0.0, -10.0))
	flag.color = Color("58d68d")

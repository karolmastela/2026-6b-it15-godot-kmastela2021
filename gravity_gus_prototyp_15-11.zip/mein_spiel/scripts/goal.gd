extends Area2D
## Zielflagge: Level geschafft = Sieg.


func _ready() -> void:
	body_entered.connect(_on_body_entered)


func _on_body_entered(body: Node2D) -> void:
	if body.is_in_group("player") and GameState.is_playing():
		GameState.add_score(100)
		GameState.win()

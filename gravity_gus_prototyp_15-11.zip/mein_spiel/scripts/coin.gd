extends Area2D
## Münze: wird eingesammelt, gibt Punkte.


func _ready() -> void:
	add_to_group("collectibles")
	body_entered.connect(_on_body_entered)


func _on_body_entered(body: Node2D) -> void:
	if body.is_in_group("player") and GameState.is_playing():
		GameState.add_coin()
		queue_free()

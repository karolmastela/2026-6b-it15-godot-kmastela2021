extends CharacterBody2D
## Gegner "Walker": läuft hin und her, dreht an Wänden und Kanten um.
## Besiegbar durch Draufspringen (Stomp), sonst verursacht er Schaden.

@export var speed: float = 40.0
@export var gravity: float = 900.0
@export var points: int = 50

var direction: float = -1.0
var _dead: bool = false

@onready var hitbox: Area2D = $Hitbox
@onready var edge_check: RayCast2D = $EdgeCheck
@onready var visual: Node2D = $Visual


func _ready() -> void:
	add_to_group("enemies")
	_update_direction()


func _physics_process(delta: float) -> void:
	if _dead or not GameState.is_playing():
		return
	velocity.y = minf(velocity.y + gravity * delta, 400.0)
	velocity.x = direction * speed
	move_and_slide()
	if is_on_wall() or (is_on_floor() and not edge_check.is_colliding()):
		direction = -direction
		_update_direction()
	_check_player_contact()


func _update_direction() -> void:
	edge_check.position.x = absf(edge_check.position.x) * direction
	edge_check.force_raycast_update()
	visual.scale.x = direction


func _check_player_contact() -> void:
	for body in hitbox.get_overlapping_bodies():
		if body.is_in_group("player"):
			_on_player_touched(body)
			return


func _on_player_touched(player: Node2D) -> void:
	# Stomp: Spieler liegt auf der "oberen" Seite (relativ zur Schwerkraft)
	# und bewegt sich in Richtung Gegner.
	var above: bool = (player.global_position.y - global_position.y) * player.gravity_sign < -4.0
	var falling: bool = player.velocity.y * player.gravity_sign > 0.0
	if above and falling:
		_die()
		player.bounce()
		GameState.add_score(points)
	else:
		player.hurt()


func _die() -> void:
	_dead = true
	remove_from_group("enemies")
	hitbox.set_deferred("monitoring", false)
	var tween := create_tween()
	tween.tween_property(visual, "scale", Vector2(visual.scale.x, 0.0), 0.15)
	tween.tween_callback(queue_free)

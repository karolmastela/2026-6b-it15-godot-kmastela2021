@tool
extends StaticBody2D
## Rechteckige Plattform (Boden, Decke, Wand). Größe und Farben im Inspector einstellbar.

@export var size: Vector2 = Vector2(32.0, 16.0):
	set(value):
		size = value
		_update()
@export var color: Color = Color("8b5a2b"):
	set(value):
		color = value
		queue_redraw()
@export var trim_color: Color = Color("58d68d"):
	set(value):
		trim_color = value
		queue_redraw()
@export var trim_height: float = 4.0:
	set(value):
		trim_height = value
		queue_redraw()
## true = Randstreifen unten (für Decken), false = oben (für Böden).
@export var trim_at_bottom: bool = false:
	set(value):
		trim_at_bottom = value
		queue_redraw()


func _ready() -> void:
	_update()


func _update() -> void:
	queue_redraw()
	var shape_node := get_node_or_null("Shape") as CollisionShape2D
	if shape_node == null:
		return
	var rect := RectangleShape2D.new()
	rect.size = size
	shape_node.shape = rect
	shape_node.position = size / 2.0


func _draw() -> void:
	draw_rect(Rect2(Vector2.ZERO, size), color)
	if trim_color.a > 0.0 and trim_height > 0.0:
		var y: float = size.y - trim_height if trim_at_bottom else 0.0
		draw_rect(Rect2(0.0, y, size.x, minf(trim_height, size.y)), trim_color)

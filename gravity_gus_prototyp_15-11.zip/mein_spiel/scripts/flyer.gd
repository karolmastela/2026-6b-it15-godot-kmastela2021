extends Area2D
## Gegner "Flyer": fliegt in Wellen hin und her. Nur ausweichen!

@export var speed: float = 40.0
@export var patrol_range: float = 70.0
@export var wave_amplitude: float = 20.0
@export var wave_frequency: float = 2.5

var _origin: Vector2 = Vector2.ZERO
var _time: float = 0.0
var _dir: float = 1.0


func _ready() -> void:
	add_to_group("enemies")
	_origin = position


func _physics_process(delta: float) -> void:
	if not GameState.is_playing():
		return
	_time += delta
	position.x += speed * _dir * delta
	if absf(position.x - _origin.x) >= patrol_range:
		position.x = _origin.x + patrol_range * _dir
		_dir = -_dir
	position.y = _origin.y + sin(_time * wave_frequency) * wave_amplitude
	for body in get_overlapping_bodies():
		if body.is_in_group("player"):
			body.hurt()

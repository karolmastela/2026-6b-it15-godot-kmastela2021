@tool
extends Area2D
## Stacheln: verursachen sofort Schaden. Können am Boden (nach oben) oder an der Decke (nach unten) sitzen.

@export var size: Vector2 = Vector2(32.0, 8.0):
	set(value):
		size = value
		_update()
@export var points_down: bool = false:
	set(value):
		points_down = value
		queue_redraw()
@export var color: Color = Color("e74c3c"):
	set(value):
		color = value
		queue_redraw()
@export var tooth_width: float = 8.0:
	set(value):
		tooth_width = maxf(value, 2.0)
		queue_redraw()


func _ready() -> void:
	add_to_group("hazards")
	_update()


func _physics_process(_delta: float) -> void:
	if Engine.is_editor_hint():
		return
	for body in get_overlapping_bodies():
		if body.has_method("hurt"):
			body.hurt()


func _update() -> void:
	queue_redraw()
	var shape_node := get_node_or_null("Shape") as CollisionShape2D
	if shape_node == null:
		return
	var rect := RectangleShape2D.new()
	rect.size = size
	shape_node.shape = rect
	shape_node.position = size / 2.0


func _draw() -> void:
	var count: int = maxi(int(size.x / tooth_width), 1)
	var w: float = size.x / count
	var base_y: float = 0.0 if points_down else size.y
	var tip_y: float = size.y if points_down else 0.0
	for i in count:
		var x: float = i * w
		draw_colored_polygon(PackedVector2Array([
			Vector2(x, base_y), Vector2(x + w / 2.0, tip_y), Vector2(x + w, base_y)
		]), color)

extends CharacterBody2D
## Spielfigur "Gus": laufen, springen und die Schwerkraft umdrehen (Twist).

signal flip_energy_changed(energy: float)

@export_group("Bewegung")
@export var speed: float = 110.0
@export var acceleration: float = 900.0
@export var friction: float = 1100.0

@export_group("Springen")
@export var jump_impulse: float = 290.0
@export var gravity: float = 900.0
@export var max_fall_speed: float = 360.0
## Kurze Zeit nach dem Verlassen einer Kante darf man noch springen.
@export var coyote_time: float = 0.1
## Ein zu früh gedrückter Sprung wird kurz gespeichert.
@export var jump_buffer_time: float = 0.1
@export var stomp_bounce: float = 220.0

@export_group("Schwerkraft-Flip")
@export var flip_cooldown: float = 1.5

@export_group("Leben")
@export var invulnerable_time: float = 1.5

## +1 = Schwerkraft nach unten, -1 = Schwerkraft nach oben.
var gravity_sign: float = 1.0
var respawn_position: Vector2 = Vector2.ZERO

var _flip_timer: float = 0.0
var _coyote: float = 0.0
var _jump_buffer: float = 0.0
var _invulnerable: float = 0.0
var _facing: float = 1.0

@onready var visual: Node2D = $Visual
@onready var camera: Camera2D = $Camera2D


func _ready() -> void:
	add_to_group("player")
	respawn_position = global_position
	_apply_gravity_direction()


func _physics_process(delta: float) -> void:
	if not GameState.is_playing():
		return
	_update_timers(delta)
	_handle_flip()
	_handle_gravity(delta)
	_handle_jump()
	_handle_movement(delta)
	move_and_slide()
	_update_visual()


func _update_timers(delta: float) -> void:
	_flip_timer = maxf(_flip_timer - delta, 0.0)
	flip_energy_changed.emit(1.0 - _flip_timer / flip_cooldown)
	_invulnerable = maxf(_invulnerable - delta, 0.0)
	if is_on_floor():
		_coyote = coyote_time
	else:
		_coyote = maxf(_coyote - delta, 0.0)
	if Input.is_action_just_pressed("jump"):
		_jump_buffer = jump_buffer_time
	else:
		_jump_buffer = maxf(_jump_buffer - delta, 0.0)


func _handle_flip() -> void:
	if Input.is_action_just_pressed("flip_gravity") and _flip_timer <= 0.0:
		gravity_sign = -gravity_sign
		_apply_gravity_direction()
		velocity.y = 0.0
		_coyote = 0.0
		_flip_timer = flip_cooldown


func _apply_gravity_direction() -> void:
	# Für is_on_floor(): "oben" ist immer die Richtung entgegen der Schwerkraft.
	up_direction = Vector2(0.0, -gravity_sign)


func _handle_gravity(delta: float) -> void:
	velocity.y += gravity * gravity_sign * delta
	velocity.y = clampf(velocity.y, -max_fall_speed, max_fall_speed)


func _handle_jump() -> void:
	if _jump_buffer > 0.0 and _coyote > 0.0:
		velocity.y = -jump_impulse * gravity_sign
		_jump_buffer = 0.0
		_coyote = 0.0
	# Variable Sprunghöhe: Taste früh loslassen = kleinerer Sprung.
	if Input.is_action_just_released("jump") and velocity.y * gravity_sign < 0.0:
		velocity.y *= 0.5


func _handle_movement(delta: float) -> void:
	var direction: float = Input.get_axis("move_left", "move_right")
	if direction != 0.0:
		_facing = signf(direction)
		velocity.x = move_toward(velocity.x, direction * speed, acceleration * delta)
	else:
		velocity.x = move_toward(velocity.x, 0.0, friction * delta)


func _update_visual() -> void:
	visual.scale = Vector2(_facing, gravity_sign)
	if _invulnerable > 0.0:
		visual.visible = int(_invulnerable * 12.0) % 2 == 0
	else:
		visual.visible = true


## Wird von Gegnern, Stacheln und Abgründen aufgerufen.
func hurt(ignore_invulnerability: bool = false) -> void:
	if not GameState.is_playing():
		return
	if _invulnerable > 0.0 and not ignore_invulnerability:
		return
	GameState.damage_player(1)
	if GameState.is_playing():
		_respawn()


## Kleiner Sprung nach einem erfolgreichen Stomp auf einen Gegner.
func bounce() -> void:
	velocity.y = -stomp_bounce * gravity_sign


func set_checkpoint(new_position: Vector2) -> void:
	respawn_position = new_position


func _respawn() -> void:
	global_position = respawn_position
	velocity = Vector2.ZERO
	gravity_sign = 1.0
	_apply_gravity_direction()
	_invulnerable = invulnerable_time
	camera.reset_smoothing()

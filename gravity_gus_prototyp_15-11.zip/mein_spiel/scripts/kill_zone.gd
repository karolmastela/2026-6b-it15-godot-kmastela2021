extends Area2D
## Unsichtbare Zone außerhalb des Levels: wer hineinfällt, verliert ein Leben.

@export var size: Vector2 = Vector2(2600.0, 40.0)


func _ready() -> void:
	var rect := RectangleShape2D.new()
	rect.size = size
	$Shape.shape = rect
	$Shape.position = size / 2.0
	body_entered.connect(_on_body_entered)


func _on_body_entered(body: Node2D) -> void:
	if body.is_in_group("player"):
		body.hurt(true)

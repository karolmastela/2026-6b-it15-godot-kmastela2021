extends Node
## Zentraler Spielzustand (Autoload "GameState").
## Hier liegen Punkte, Leben, Münzen und der aktuelle Zustand (State Machine).
## Andere Nodes lesen den Zustand oder reagieren auf die Signals.

enum State { MENU, PLAYING, PAUSED, GAME_OVER, WON }

signal state_changed(new_state: State)
signal score_changed(new_score: int)
signal health_changed(new_health: int)
signal coins_changed(new_coins: int)

const START_HEALTH: int = 3
const COIN_POINTS: int = 10

var state: State = State.MENU
var score: int = 0
var health: int = START_HEALTH
var coins: int = 0


func start_game() -> void:
	score = 0
	coins = 0
	health = START_HEALTH
	score_changed.emit(score)
	coins_changed.emit(coins)
	health_changed.emit(health)
	_set_state(State.PLAYING)


func add_score(points: int) -> void:
	score += points
	score_changed.emit(score)


func add_coin() -> void:
	coins += 1
	coins_changed.emit(coins)
	add_score(COIN_POINTS)


func damage_player(amount: int = 1) -> void:
	health = maxi(health - amount, 0)
	health_changed.emit(health)
	if health == 0:
		game_over()


func game_over() -> void:
	_set_state(State.GAME_OVER)


func win() -> void:
	_set_state(State.WON)


func toggle_pause() -> void:
	if state == State.PLAYING:
		_set_state(State.PAUSED)
	elif state == State.PAUSED:
		_set_state(State.PLAYING)


func is_playing() -> bool:
	return state == State.PLAYING


func _set_state(new_state: State) -> void:
	state = new_state
	state_changed.emit(state)

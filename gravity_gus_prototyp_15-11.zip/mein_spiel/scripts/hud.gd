extends CanvasLayer
## Einfaches HUD mit Platzhalter-Optik. Reagiert nur auf Signals von GameState.

@onready var health_label: Label = %HealthLabel
@onready var score_label: Label = %ScoreLabel
@onready var coin_label: Label = %CoinLabel
@onready var flip_bar: ProgressBar = %FlipBar
@onready var state_label: Label = %StateLabel


func _ready() -> void:
	GameState.health_changed.connect(_on_health_changed)
	GameState.score_changed.connect(_on_score_changed)
	GameState.coins_changed.connect(_on_coins_changed)
	GameState.state_changed.connect(_on_state_changed)
	_on_health_changed(GameState.health)
	_on_score_changed(GameState.score)
	_on_coins_changed(GameState.coins)
	_on_state_changed(GameState.state)


func set_flip_energy(energy: float) -> void:
	flip_bar.value = energy * 100.0


func _on_health_changed(new_health: int) -> void:
	health_label.text = "Leben: %d" % new_health


func _on_score_changed(new_score: int) -> void:
	score_label.text = "Score: %06d" % new_score


func _on_coins_changed(new_coins: int) -> void:
	coin_label.text = "Münzen: %d" % new_coins


func _on_state_changed(new_state: GameState.State) -> void:
	match new_state:
		GameState.State.PAUSED:
			state_label.text = "PAUSE\n\nEsc = weiter   R = Neustart"
		GameState.State.GAME_OVER:
			state_label.text = "GAME OVER\n\nR = Neustart"
		GameState.State.WON:
			state_label.text = "LEVEL GESCHAFFT!\n\nScore: %d\nR = Neustart" % GameState.score
		_:
			state_label.text = ""

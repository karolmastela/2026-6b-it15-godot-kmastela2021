extends Node2D
## Hauptszene: startet das Spiel, verbindet Signals und kümmert sich um Pause/Neustart.

## Breite des Levels in Pixeln (für die Kamera-Begrenzung).
@export var level_width: int = 2400
## Höhe des Levels in Pixeln.
@export var level_height: int = 180

@onready var player: CharacterBody2D = $Player
@onready var hud: CanvasLayer = $HUD
@onready var camera: Camera2D = $Player/Camera2D


func _ready() -> void:
	camera.limit_left = 0
	camera.limit_top = 0
	camera.limit_right = level_width
	camera.limit_bottom = level_height
	# "Call down, signal up": der Spieler meldet per Signal, das HUD zeigt an.
	player.flip_energy_changed.connect(hud.set_flip_energy)
	GameState.start_game()


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("pause"):
		GameState.toggle_pause()
	elif event.is_action_pressed("restart"):
		restart()


func restart() -> void:
	GameState.start_game()
	get_tree().reload_current_scene()
